import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

DATA = "data/logistics_analysis_dataset.csv"
OUT = Path("visualizations")
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA, parse_dates=["Order_Date"])

# Summary statistics
summary = df[[
    "Quantity", "Shipping_Cost_INR",
    "Shipping_Time_Days", "Inventory_Level"
]].describe()
summary.to_csv(OUT / "summary_statistics.csv")

# 1. Transport mode distribution
df["Transport_Mode"].value_counts().plot(kind="bar")
plt.title("Orders by Transport Mode")
plt.xlabel("Transport Mode")
plt.ylabel("Number of Orders")
plt.tight_layout()
plt.savefig(OUT / "transport_mode_distribution.png", dpi=150)
plt.close()

# 2. Shipping cost by transport mode
df.boxplot(column="Shipping_Cost_INR", by="Transport_Mode")
plt.title("Shipping Cost by Transport Mode")
plt.suptitle("")
plt.xlabel("Transport Mode")
plt.ylabel("Shipping Cost (INR)")
plt.tight_layout()
plt.savefig(OUT / "shipping_cost_by_transport_mode.png", dpi=150)
plt.close()

# 3. Shipping time distribution
df["Shipping_Time_Days"].plot(kind="hist", bins=10)
plt.title("Shipping Time Distribution")
plt.xlabel("Shipping Time (Days)")
plt.ylabel("Frequency")
plt.tight_layout()
plt.savefig(OUT / "shipping_time_distribution.png", dpi=150)
plt.close()

# 4. Quantity vs shipping cost
plt.scatter(df["Quantity"], df["Shipping_Cost_INR"])
plt.title("Quantity vs Shipping Cost")
plt.xlabel("Quantity")
plt.ylabel("Shipping Cost (INR)")
plt.tight_layout()
plt.savefig(OUT / "quantity_vs_shipping_cost.png", dpi=150)
plt.close()

# 5. Correlation heatmap
corr = df[["Quantity","Shipping_Cost_INR","Shipping_Time_Days","Inventory_Level"]].corr()
plt.imshow(corr, cmap="viridis", aspect="auto")
plt.colorbar(label="Correlation")
plt.xticks(range(len(corr.columns)), corr.columns, rotation=45, ha="right")
plt.yticks(range(len(corr.columns)), corr.columns)
plt.title("Correlation Matrix")
plt.tight_layout()
plt.savefig(OUT / "correlation_matrix.png", dpi=150)
plt.close()

print("Analysis and visualizations completed.")
