# Week 4 – Predictive Modeling and Optimization
Predictive modeling of logistics shipping time and transport optimization scenarios.
