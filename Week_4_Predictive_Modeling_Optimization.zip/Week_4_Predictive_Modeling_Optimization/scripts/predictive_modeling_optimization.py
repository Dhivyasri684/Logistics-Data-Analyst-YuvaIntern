import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

df = pd.read_csv("data/logistics_predictive_modeling_dataset.csv")
features = ["Quantity","Shipping_Cost_INR","Inventory_Level","Product_Category","Transport_Mode"]
X, y = df[features], df["Shipping_Time_Days"]
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2,random_state=42)

pre = ColumnTransformer([
    ("num","passthrough",["Quantity","Shipping_Cost_INR","Inventory_Level"]),
    ("cat",OneHotEncoder(handle_unknown="ignore"),["Product_Category","Transport_Mode"])
])
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(n_estimators=200,random_state=42)
}
for name, model in models.items():
    pipe = Pipeline([("preprocess",pre),("model",model)])
    pipe.fit(X_train,y_train)
    pred = pipe.predict(X_test)
    print(name, "MAE=",mean_absolute_error(y_test,pred),
          "RMSE=",mean_squared_error(y_test,pred)**0.5,
          "R2=",r2_score(y_test,pred))

# Extend this workflow with cross-validation and constrained optimization
# for production logistics decisions.
